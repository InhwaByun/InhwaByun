function check(form)
{
    if(form.userid.value=="helloworld")
    {
        if(form.userpassword.value=="123456")
        {
            window.open('HW_Home.html')
        }
        else
        {
            alert("비밀번호를 잘못 입력했습니다.입력하신 내용을 다시 확인해주세요.");
        }
}
else{
    alert("아이디를 잘못 입력했습니다.입력하신 내용을 다시 확인해주세요.");
    }
}