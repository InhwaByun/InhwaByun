var slideIndex = 1;   // 슬라이드 초기값
showSlides(slideIndex);  // 시작시 실행되는 showSlides()함수 slideIndex=1

// Next/previous controls  양 옆 화살표 onclick 함수
function plusSlides(n) {
  showSlides(slideIndex += n);  // n값을 불러와서 slideIndex의 값에 더한 후 showSlides 함수 실행
}                             

// Thumbnail image controls 버튼 클릭시 실행되는 함수
function currentSlide(n) {   // n값을 불러와서 slideindex의 값에 대입한 후 showslides 함수 실행
  showSlides(slideIndex = n);
}

function showSlides(n) {   //showSlides 함수 실행, 전달받은 값을 n으로 지정
  var i;  //반복문 초기화
  var slides = document.getElementsByClassName("mySlides");  // 각 사진이 들어있는 div.mySlides 불러옴
  var dots = document.getElementsByClassName("dot");  // 각 이미지에 대한 버튼 클래스를 불러옴
  if (n >slides.length) {slideIndex = 1}
   // n이 1보다 큰 경우 전달받은 n의 값이 길이보다 크면 1로 초기화 즉 다시 첫번째 사진 인덱스로 만듦
  
   if (n < 1) {slideIndex = slides.length}
    // n이 1보다 작을 경우 div.mySlide 의 길이를 인덱스로 설정

  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  // 모든 사진을 none으로 처리
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }  // dot 클래스가 갖고있는 모든 active 클래스를 지운다 ("" 로 치환)

  slides[slideIndex-1].style.display = "block";
  // slides[slideIndex - 1] if문으로 처리받은 slideIndex값에 -1을 해 slides 의 클래스를 block으로 만듦
  dots[slideIndex-1].className += " active";
} // 그에 맞는 dot 클래스를 가진 span에 active 클래스를 추가한다


